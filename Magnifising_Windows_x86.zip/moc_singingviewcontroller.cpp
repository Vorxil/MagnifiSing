/****************************************************************************
** Meta object code from reading C++ file 'singingviewcontroller.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../src/singingviewcontroller.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'singingviewcontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SingingViewController_t {
    QByteArrayData data[13];
    char stringdata0[151];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SingingViewController_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SingingViewController_t qt_meta_stringdata_SingingViewController = {
    {
QT_MOC_LITERAL(0, 0, 21), // "SingingViewController"
QT_MOC_LITERAL(1, 22, 11), // "readSamples"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 14), // "updateMidiView"
QT_MOC_LITERAL(4, 50, 10), // "play_pause"
QT_MOC_LITERAL(5, 61, 4), // "stop"
QT_MOC_LITERAL(6, 66, 14), // "updateMidiFile"
QT_MOC_LITERAL(7, 81, 8), // "filepath"
QT_MOC_LITERAL(8, 90, 12), // "setToneTrack"
QT_MOC_LITERAL(9, 103, 5), // "track"
QT_MOC_LITERAL(10, 109, 12), // "setTextTrack"
QT_MOC_LITERAL(11, 122, 18), // "setSilentThreshold"
QT_MOC_LITERAL(12, 141, 9) // "threshold"

    },
    "SingingViewController\0readSamples\0\0"
    "updateMidiView\0play_pause\0stop\0"
    "updateMidiFile\0filepath\0setToneTrack\0"
    "track\0setTextTrack\0setSilentThreshold\0"
    "threshold"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SingingViewController[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   54,    2, 0x0a /* Public */,
       3,    0,   55,    2, 0x0a /* Public */,
       4,    0,   56,    2, 0x0a /* Public */,
       5,    0,   57,    2, 0x0a /* Public */,
       6,    1,   58,    2, 0x0a /* Public */,
       8,    1,   61,    2, 0x0a /* Public */,
      10,    1,   64,    2, 0x0a /* Public */,
      11,    1,   67,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,   12,

       0        // eod
};

void SingingViewController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SingingViewController *_t = static_cast<SingingViewController *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->readSamples(); break;
        case 1: _t->updateMidiView(); break;
        case 2: _t->play_pause(); break;
        case 3: _t->stop(); break;
        case 4: _t->updateMidiFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->setToneTrack((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->setTextTrack((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->setSilentThreshold((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject SingingViewController::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_SingingViewController.data,
      qt_meta_data_SingingViewController,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *SingingViewController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SingingViewController::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_SingingViewController.stringdata0))
        return static_cast<void*>(const_cast< SingingViewController*>(this));
    return QObject::qt_metacast(_clname);
}

int SingingViewController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
